const formatServiceReturn = (status, code, data = null, message = null) => ({
    status, code, data, message
});

exports.formatServiceReturn = formatServiceReturn;

module.exports = exports;
