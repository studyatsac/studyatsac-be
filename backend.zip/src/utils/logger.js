const loggingError = (err) => {
    // TODO: Logging to file
    console.log(err);
};

exports.loggingError = loggingError;

module.exports = exports;
