exports.item = (data) => ({
    uuid: data.uuid,
    title: data.title
});

module.exports = exports;
