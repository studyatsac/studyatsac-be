exports.item = (data) => ({
    userId: data.userId,
    examPackageId: data.examPackageId
});

module.exports = exports;
