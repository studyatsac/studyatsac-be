// const Models = require('../../models/mongodb');

exports.push = function (data) {
    // just temporarily
    console.log(data);
    // return Models.Log.create(data);
};

module.exports = exports;
